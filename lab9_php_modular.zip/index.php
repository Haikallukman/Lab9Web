<?php
require 'config.php';
require 'templates/header.php';

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    $file = $page . ".php";
    if (file_exists($file)) {
        require $file;
    } else {
        echo "<h2>404 - Halaman tidak ditemukan</h2>";
    }
} else {
    echo "<h2>Selamat Datang di Home</h2>";
    echo "<p>Silakan pilih menu di atas.</p>";
}

require 'templates/footer.php';
?>
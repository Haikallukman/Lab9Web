<footer>
    <p>&copy; 2025 – Informatika Universitas Pelita Bangsa</p>
</footer>
</div>
</body>
</html>
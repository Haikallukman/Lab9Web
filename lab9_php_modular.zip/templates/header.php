<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Aplikasi Modular PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<header>
    <h1>Modularisasi PHP + Routing</h1>
</header>
<nav>
    <a href="index.php?page=user/list">Daftar User</a>
    <a href="index.php?page=user/tambah">Tambah User</a>
</nav>
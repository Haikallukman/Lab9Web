<?php
$id = $_GET['id'];
mysqli_query($koneksi, "DELETE FROM user WHERE id='$id'");
echo "<script>location='index.php?page=user/list'</script>";
?>
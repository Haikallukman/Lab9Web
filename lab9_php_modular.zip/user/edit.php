<?php
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM user WHERE id='$id'"));
if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    mysqli_query($koneksi, "UPDATE user SET nama='$nama', email='$email' WHERE id='$id'");
    echo "<script>location='index.php?page=user/list'</script>";
}
?>
<h2>Edit User</h2>
<form method="POST">
Nama:<br><input type="text" name="nama" value="<?= $data['nama']; ?>"><br><br>
Email:<br><input type="text" name="email" value="<?= $data['email']; ?>"><br><br>
<button type="submit" name="update">Update</button>
</form>